import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managequiz',
  templateUrl: './managequiz.component.html',
  styleUrls: ['./managequiz.component.css']
})
export class ManagequizComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
