import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managequestions',
  templateUrl: './managequestions.component.html',
  styleUrls: ['./managequestions.component.css']
})
export class ManagequestionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
